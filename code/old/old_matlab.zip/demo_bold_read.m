clear all; close all; clc

% 02.08.24
% demonstrate reading in fMRI-BOLD for Amilcar

% you will need the function load_untouch_nii() 
% get it from https://www.mathworks.com/matlabcentral/fileexchange/8797-tools-for-nifti-and-analyze-image
% or https://github.com/dmochow/jd-lab-common

% point this to your paths
addpath(genpath('/Users/jacekdmochowski/PROJECTS/jd-lab-common')); 
path_to_data = '/Users/jacekdmochowski/PROJECTS/fus/data/SUBJECTS/JD_testing_trigger/unknown/rfMRI_REST_AP'; 

%% identify the json file that carries scan parameters
json_filename = dir(fullfile(path_to_data,'*.json'));
/*  */
%% read the fields of the json file
jsonstr = fileread(fullfile(json_filename.folder,json_filename.name)); 
jsondata = jsondecode(jsonstr);

% get the TR
TR = jsondata.RepetitionTime;

%% identify the actual bold datafile
nii_filename = dir(fullfile(path_to_data,'*.nii'));
if isempty(nii_filename)
    nii_filename = dir(fullfile(path_to_data,'*.nii.gz'));
    if isempty(nii_filename)
        error("Unable to find nii filename")
    end
end

%% read in the bold data
nii = load_untouch_nii(fullfile(nii_filename.folder,nii_filename.name));
bold = double(nii.img);
size(bold)

%% visualize every 30th TR
n_rows = 2;
n_cols = 5;
axial_slice=36; % mid-slice

figure
colormap bone
for sl=1:n_rows*n_cols
    subplot(n_rows,n_cols,sl)
    imagesc(bold(:,:,axial_slice,sl))
    axis equal
    axis off
end

%% visualize time series of an individual voxel

% specify the times of each BOLD sample
TR_onsets = (0:size(bold,4)-1) * TR;

% pick the voxel that you want to visualize here
voxel_coords = [52,52,36];

% grab time series of the chosen voxel
bold_ts = bold(voxel_coords(1),voxel_coords(2),voxel_coords(3),:);
bold_ts = squeeze(bold_ts);

% plot
figure;
plot(TR_onsets,bold_ts);



