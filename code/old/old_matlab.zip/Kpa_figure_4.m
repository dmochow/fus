clear; clc;
load KPa_datas4.mat

%% Modifiable Variables

att = 0.6; % Head Attenuaion (fraction), this is not the 6db attenuator.
Duty_cycle = .25;
focus = 50;

n1 = 3; % Data Acquired = 1 (with 6db att), 2 (No att), 3 (all data)
n2 = 1; % Data Acquired for curve fit (Use 1 or 2, not 3)

%% Setup
focuses = focuses(1:3);
za = 1.5e6; % Water Acoustic Impedance kg/(sec*m^2)
zb = 1.6e6; % Brain Acoustic Impedance kg/(sec*m^2)
TPOI2 = TPOI2(1:12);

% Ps_max = mean(Ps_max);
% P_brain = Ps_max*(1-att);
% IWater = (Ps_max*1000/100).^2/(2*za)*1000;
% IBrain = (P_brain*1000/100).^2/(2*zb)*1000;


%% Figure of all focuses

close all;

switch n1
    case 1 % use only attenuators
        volts_use = Chsatt_volts;
        kpa_use = KPa_max;
    case 2 % no attenuators
        volts_use = Chs_volts;
        kpa_use = KPa_max2;
    case 3 % use all
        volts_use = cat(1,Chsatt_volts,Chs_volts);
        kpa_use = [KPa_max KPa_max2];
end

for i = 1:length(focuses)
    
    x1 = volts_use(:,1,i);
    x2 = volts_use(:,2,i);

    y_pwater = kpa_use(i,:);
    y_pbrain = y_pwater*(1-att);
    yI = (y_pbrain*1000/100).^2/(2*zb)*1000*Duty_cycle;

    figure(1)
    subplot(1,3,1)
    scatter(x1,y_pwater,[],ones(length(x1),1)*focuses(i),'filled'); hold on;
    subplot(1,3,2)
    scatter(x2,y_pwater,[],ones(length(x1),1)*focuses(i),'filled'); hold on;
    subplot(1,3,3)
    scatter(x1+x2,y_pwater,[],ones(length(x1),1)*focuses(i),'filled'); hold on;

    figure(2);
    subplot(1,3,1)
    scatter(x1,y_pbrain,[],ones(length(x1),1)*focuses(i),'filled'); hold on;
    subplot(1,3,2)
    scatter(x2,y_pbrain,[],ones(length(x1),1)*focuses(i),'filled'); hold on;
    subplot(1,3,3)
    scatter(x1+x2,y_pbrain,[],ones(length(x1),1)*focuses(i),'filled'); hold on;

    figure(3)
    subplot(1,3,1)
    scatter(x1,yI,[],ones(length(x1),1)*focuses(i),'filled'); hold on;
    subplot(1,3,2)
    scatter(x2,yI,[],ones(length(x1),1)*focuses(i),'filled'); hold on;
    subplot(1,3,3)
    scatter(x1+x2,yI,[],ones(length(x1),1)*focuses(i),'filled'); hold on;

end

figure(1);
subplot(131); xlabel('CH1 Peak (volts)'); ylabel('Peak Pressure (KPa)');
colormap jet; 
subplot(132); xlabel('CH2 Peak (volts)');
colormap jet; 
subplot(133); xlabel('CH1 + CH2');
sgtext = {"Water tank Pressure"};
sgtitle(sgtext)
colormap jet; 
hcb= colorbar;
hcb.Title.String = "Focus (mm)";

figure(2);
subplot(131); xlabel('CH1 Peak (volts)'); ylabel('Peak Pressure (KPa)');
colormap jet; 
subplot(132); xlabel('CH2 Peak (volts)');
colormap jet; 
subplot(133); xlabel('CH1 + CH2');
tmp = sprintf('Brain Attenuation = %d%%', att*100);
sgtext = {"Brain Pressure by Transducer Voltage";tmp};
sgtitle(sgtext)
colormap jet; 
hcb= colorbar;
hcb.Title.String = "Focus (mm)";

figure(3);
subplot(131); xlabel('CH1 Peak (volts)'); ylabel('Ispta mW/cm^2');
colormap jet; 
subplot(132); xlabel('CH2 Peak (volts)');
colormap jet; 
subplot(133); xlabel('CH1 + CH2');
tmp = sprintf('Brain Attenuation = %d%%, Duty Cycle = %d%%', att*100, Duty_cycle*100);
sgtext = {"Brain Ispta by Transducer Voltage";tmp};
sgtitle(sgtext)
colormap jet; 
hcb= colorbar;
hcb.Title.String = "Focus (mm)";




%% Single Focus Curve Fit
 
switch n2
    case 1 % use only attenuators
        volts_use = Chsatt_volts;
        kpa_use = KPa_max;
    case 2 % no attenuators
        volts_use = Chs_volts;
        kpa_use = KPa_max2;
    case 3 % use all
        volts_use = cat(1,Chsatt_volts,Chs_volts);
        kpa_use = [KPa_max KPa_max2];
end

i = find(focuses == focus);
x1 = volts_use(:,1,i);
x2 = volts_use(:,2,i);
x3 = x1+x2;

y_pwater = kpa_use(i,:);
y_pbrain = y_pwater*(1-att);
yI = (y_pbrain*1000/100).^2/(2*zb)*1000*Duty_cycle;


figure(4)
x = x1; y = y_pbrain;
subplot(1,3,1)
scatter(x1,y); hold on;
P = polyfit(x,y,1);
xfit = (min(x):.5:max(x));
yfit = P(1)*xfit+P(2);
hold on;
plot(xfit,yfit,'r.');

subplot(1,3,2)
x = x2;
scatter(x,y); hold on;
P = polyfit(x,y,1);
xfit = (min(x):.05:max(x));
yfit = P(1)*xfit+P(2);
hold on;
plot(xfit,yfit,'r.');

subplot(1,3,3)
x = x3;
scatter(x,y); hold on;
P = polyfit(x,y,1);
xfit = (min(x):.5:max(x));
yfit = P(1)*xfit+P(2);
hold on;
plot(xfit,yfit,'r.');

subplot(131); xlabel('CH1 Peak (volts)'); ylabel('PeakPressure (KPa)');
subplot(132); xlabel('CH2 Peak (volts)');
subplot(133); xlabel('CH1 + CH2');

tmp = sprintf("Focus = %.0f mm",focus);
tmp2 = sprintf('Brain Attenuation = %d%%', att*100);
sgtext = {"Brain Pressure by Voltage";tmp;tmp2};
sgtitle(sgtext)


figure(5)
x = x1; y = yI;
subplot(1,3,1)
scatter(x1,y); hold on;
P = polyfit(x,y,2);
xfit = (min(x):.5:max(x));
yfit = P(1)*xfit.^2+P(2)*xfit+P(3);
hold on;
plot(xfit,yfit,'r.');

subplot(1,3,2)
x = x2;
scatter(x,y); hold on;
P = polyfit(x,y,2);
xfit = (min(x):.05:max(x));
yfit = P(1)*xfit.^2+P(2)*xfit+P(3);
hold on;
plot(xfit,yfit,'r.');

subplot(1,3,3)
x = x3;
scatter(x,y); hold on;
P = polyfit(x,y,2);
xfit = (min(x):.5:max(x));
yfit = P(1)*xfit.^2+P(2)*xfit+P(3);
hold on;
plot(xfit,yfit,'r.');

subplot(131); xlabel('CH1 Peak (volts)'); ylabel('mW/cm^2');
subplot(132); xlabel('CH2 Peak (volts)');
subplot(133); xlabel('CH1 + CH2');

tmp = sprintf("Focus = %.0f mm",focus);
tmp2 = sprintf('Brain Attenuation = %d%%, Duty Cycle = %d%%', att*100, Duty_cycle*100);
sgtext = {"Brain Ispta by Voltage";tmp;tmp2};
sgtitle(sgtext)


